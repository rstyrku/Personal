#include<iostream>
using namespace std;

int main(){
    // Problem 2
    
    //a
    int my_ints[4];
    
    //b
    int input;
    int x=0;
    while(x<=3){
        cout<<"Enter a Number: ";
        cin>>input;
        my_ints[x]=input;
        x++;
    }
    
    //c
    int *my_ptrs[4];
    for(int x=0; x==3; x++){
        my_ptrs[x]=&my_ints[x];
    }
    
    //d
    int min=0;
    int second=0;
    int third=0;
    int fourth=0;
    x=0;
    
    while (x<4){
        if (my_ints[x] < my_ints[min]){
            fourth=third;
            third=second;
            second=min;
            min=x;
        }
        else if (my_ints[x]>=my_ints[min]&&my_ints[x]<=my_ints[second]){
            fourth=third;
            third=second;
            second=x;
        }
        else if (my_ints[x]>my_ints[second]&&my_ints[x]<my_ints[third]){
            fourth=third;
            third=x;
        }
        else if (my_ints[x]>my_ints[fourth]){
            fourth=x;
        }
        x++;
    }
    my_ptrs[0]=&my_ints[min];
    my_ptrs[1]=&my_ints[second];
    my_ptrs[2]=&my_ints[third];
    my_ptrs[3]=&my_ints[fourth];
    
    //e
    x=0;
    while (x<4){
        cout<<"Index "<<x<<" points to the number: "<<*my_ptrs[x]<<"."<<endl;
        x++;
    }
    return 0;
}
