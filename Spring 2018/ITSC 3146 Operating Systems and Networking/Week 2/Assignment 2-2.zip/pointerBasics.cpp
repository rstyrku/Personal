#include <iostream>
using namespace std;

int main()
{
    // Problem A
    
    //i
    int myInt = 15;
    
    //ii
    int *myPointer = &myInt;
    
    // Problem B
    
    //i
    cout<<"Problem B(i)"<<endl;
    cout<<&myInt<<endl;
    cout<<myPointer<<endl<<endl;
    
    //ii
    cout<<"Problem B(ii)"<<endl;
    cout<<myInt<<endl;
    cout<<*myPointer<<endl<<endl;
    
    // Problem C
    myInt=10;
    
    // ii
    cout<<"Problem C(ii)"<<endl;
    cout<<&myInt<<endl;
    cout<<myPointer<<endl<<endl;
    
    //iii
    cout<<"Problem C(iii)"<<endl;
    cout<<myInt<<endl;
    cout<<*myPointer<<endl;
    
    return 0;
}